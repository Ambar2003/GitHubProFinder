import React,{lazy, Suspense,useContext} from "react";
import ReactDOM from "react-dom/client";
import Header from "./components/Header";
import Body from "./components/Body";
import { createBrowserRouter,RouterProvider,Outlet} from "react-router-dom";
import Contact from "./components/Contact";
import Error from "./components/Error";
import Shimmer from "./components/Shimmer";
import { useEffect } from "react";
import { useState } from "react";
const AppLayout = () =>{
    const [userName,setUserName] = useState();
    useEffect(()=>{
            const data = {
            name:"Ambar Ahmad",
        }
        setUserName(data.name);
    },[]);
    return(
    <div className = "app">
        <Header/>
        <Outlet/>
    </div>
    );
};
const About = lazy(()=>import("./components/About"));
    const appRouter = createBrowserRouter([
    {
        path:"/",
        element:<AppLayout/>,
       children:[
        {
            path:"/",
            element:<Body/>,
        },
        {
            path:"/about",
            element:(<Suspense fallback = {<Shimmer></Shimmer>}><About/></Suspense>),
        },
        {
            path:"/contact",
            element:<Contact/>,  
        },
        {
            path:"/shimmer",
            element:<Shimmer></Shimmer>
        }
       ],
        errorElement:<Error/>
    },
]);
const Title = () =>(
    <h1 className = "head" tabIndex = "5">
        Namaste React using JSX🚀
    </h1>
);
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<RouterProvider router = {appRouter}/>);
