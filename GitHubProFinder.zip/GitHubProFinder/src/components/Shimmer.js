const Shimmer = () => {
  return (
    <div className="flex flex-wrap">
        <div className="m-4 p-20 border border-gray-500">
        <div className="mx-4 p-4 h-80">Cards</div>
        </div>
      <div className="m-4 p-20 border border-gray-500" >
        <div className="mx-4 p-4 h-80">Cards</div>
      </div>
      <div className="m-4 p-20 border border-gray-500">
        <div className="mx-4 p-4 h-80">Cards</div>
      </div>
      <div className="m-4 p-20 border border-gray-500">
        <div className="mx-4 p-4 h-80">Cards</div>
      </div>
      <div className="m-4 p-20 border border-gray-500">
        <div className="mx-4 p-4 h-80">Cards</div>
      </div>
      <div className="m-4 p-20 border border-gray-500">
        <div className="mx-4 p-4 h-80">Cards</div>
      </div>
      <div className="m-4 p-20 border border-gray-500">
        <div className="mx-4 p-4 h-80">Cards</div>
      </div>
      <div className="m-4 p-20 border border-gray-500">
        <div className="mx-4 p-4 h-80">Cards</div>
      </div>
      <div className="m-4 p-20 border border-gray-500">
        <div className="mx-4 p-4 h-80">Cards</div>
      </div>
      <div className="m-4 p-20 border border-gray-500">
        <div className="mx-4 p-4 h-80">Cards</div>
      </div>
      <div className="m-4 p-20 border border-gray-500">
        <div className="mx-4 p-4 h-80">Cards</div>
      </div>
    </div>
  );
};
export default Shimmer;
