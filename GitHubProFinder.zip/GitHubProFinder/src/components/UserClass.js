import React from "react"
import { data } from "../utils/constants";
class UserClass extends React.Component{
    render(){
        const name1 = "Ambar Ahmad";
        const location1 = "Bengaluru";
        const avatar_url1 = "https://avatars.githubusercontent.com/u/94756332?v=4";
        const bio1 = "Currently a college student, aspiring to become a useful engineer😅";
        return(
            <div>
                <div>
                <h1 className="px-4 font-bold text-xl">Name: {name1}</h1>
                <h2 className="px-4 font-bold text-xl">Location: {location1}</h2>
                <img src = {avatar_url1} className="h-36 m-auto border-solid border-2 m-4 border-indigo-600 "></img>
                <h2 className="px-4 font-bold text-xl">{bio1}</h2>
                </div>
            </div>
         )
       }
}
export default UserClass;
