export function evaluateBooleanQuery(query, data) {
  const tokens = query.split(/\s+/);
  const stack = [];

  let i = 0;
  let prevToken = "";
  while (i < tokens.length) {
      const token = tokens[i];
      if (token === "AND") {
            prevToken = token;
          i++;  // Move to the next token
          continue;
      } else if (token === "OR") {
        prevToken = token;
          // Combine all conditions until the last AND operator
          const orConditions = [];
          while (stack.length && stack[stack.length - 1] !== "AND") {
              orConditions.push(...stack.pop());
          }
          const result = [...new Set(orConditions)];
          stack.push(result);
          console.log(stack);
      } else {
          // Token is an attribute/value
          const matchingItems = data.filter(data => data.name.toLowerCase().includes(token.toLowerCase()));
          if(matchingItems.length == 0 && prevToken == "AND"){
            return [];
          }
          stack.push(matchingItems);
      }
      i++;
  }

  // Combine remaining conditions
  const finalResult = [].concat(...stack);
  // console.log(stack);
  return finalResult;
}