import { CDN_URL } from "../utils/constants";
import Shimmer from "./Shimmer";
import React from "react";
import { useState, useEffect } from "react";
import { data } from "../utils/constants";
import { evaluateBooleanQuery } from "./booleanQueryEvaluator";
const ProfileCard = ({ resData }) => {
    const[profilesList,setProfilesList] = useState(data);
    const[filteredprofilesList,setFilteredProfilesList] = useState(data);
    // console.log(profilesList);
    const [searchText,setSearchText] = useState("");
    return (
        <div>
        <div className="flex flex-wrap">
            <div className="mx-2 my-4">
    <input type = "text" className="text-xl bg-pink-200" value = {searchText} placeholder="Search Profiles" onChange={(e) =>{
        setSearchText(e.target.value)}} ></input>
    <button onClick={(query)=>{
        const filteredProfile = handleIt(profilesList,searchText)
      setFilteredProfilesList(filteredProfile);
    }} 
    className="mx-2 bg-green-400 text-2xl rounded-1xl" >Search</button>
              </div>
              <div className="mx-2 my-4">
    <button onClick={(query)=>{
        const filteredProfile = profilesList.filter(
            (profile) =>profile.followers>5
        );
        setFilteredProfilesList(filteredProfile);
    }} 
    className="mx-2 bg-green-400 text-2xl rounded-1xl">Most Popular</button>
              </div>
              <div className="mx-2 my-4">
    <button onClick={(query)=>{
        const filteredProfile = profilesList.filter(
            (profile) =>profile.following>4
        );
        setFilteredProfilesList(filteredProfile);
    }} 
    className="mx-2 bg-green-400 text-2xl rounded-1xl">Most Following</button>
              </div>
              <div className="mx-2 my-4">
    <button onClick={(query)=>{
        const filteredProfile = profilesList.filter(
            (profile) =>profile.created_at.substring(0,4) === "2021"
        );
        setFilteredProfilesList(filteredProfile);
    }} 
    className="mx-2 bg-green-400 text-2xl rounded-1xl">Early Birds</button>
              </div>
              </div>
              <div className="flex flex-wrap cursor-pointer">
      {profilesList ? (
        filteredprofilesList.map((profile, index) => (
          <a href = {profile.link}>
          <div key={index} className="res-card p-4 m-4 w-[400px] bg-gray-200 hover:bg-gray-400">
            <img
              className="res-logo"
              alt="res-logo"
              src={profile.avatar_url} // Accessing avatar_url from the profile object
            />
            <h4 className="text-xl">Name: {profile.name}</h4>
            <h4 className="text-xl">About: {profile.bio}</h4>
            <h4 className="text-xl">Followers: {profile.followers}</h4>
            <h4 className="text-xl">Following: {profile.following}</h4>
            <h4 className="text-xl">Account created on: {profile.created_at.substring(0, 10)}</h4>
          </div>
          </a>
        ))
      ) : (
        <Shimmer /> // Assuming Shimmer is a loading placeholder component
      )}
   
        </div>
        </div>
    );
};
// AMBAR AND AMOGH
const handleIt =  (profilesList,searchText) =>{
  if(searchText.includes("AND") && searchText.includes("OR")){
    return evaluateBooleanQuery(searchText,profilesList);
  }
  if(searchText.includes("AND")){
    const conditions = searchText.split("AND").map((condition) => condition.trim().toLowerCase());
  if (conditions.length === 0) {
    return []; // Return empty array if no valid conditions
  }
   filteredProfiles = [];
     conditions.map((condition,index) => {
      const filteredProfile = profilesList.filter((profile) =>
      profile.name.toLowerCase().includes(condition.toLowerCase())
    );
    filteredProfiles = filteredProfiles.concat(filteredProfile);
    });
    return filteredProfiles.length == conditions.length?filteredProfiles:[];
  }
  if(searchText.includes("NOR")){
    const conditions = searchText.split("NOR").map((condition) => condition.trim().toLowerCase());
  if (conditions.length === 0) {
    return []; // Return empty array if no valid conditions
  }
   filteredProfiles = [];
     conditions.map((condition,index) => {
      const filteredProfile = profilesList.filter((profile) =>
      profile.name.toLowerCase().includes(condition.toLowerCase())
    );
    filteredProfiles = filteredProfiles.concat(filteredProfile);
    });
    console.log(filteredProfiles.length);
    if(filteredProfiles.length == 0){
      return <Error></Error>
    }else{
      return [];
    }
  }
  if(searchText.includes("OR")){
    const conditions = searchText.split("OR").map((condition) => condition.trim().toLowerCase());
  if (conditions.length === 0) {
    return []; // Return empty array if no valid conditions
  }
  filteredProfiles = [];
     conditions.map((condition,index) => {
      const filteredProfile = profilesList.filter((profile) =>
      profile.name.toLowerCase().includes(condition.toLowerCase())
    );
    filteredProfiles = filteredProfiles.concat(filteredProfile);
    });
    return filteredProfiles;
  }
  const filteredProfile = profilesList.filter(
    (profile) =>profile.name.toLowerCase().includes(searchText.toLowerCase())
);
  return filteredProfile;
}

export default ProfileCard;
