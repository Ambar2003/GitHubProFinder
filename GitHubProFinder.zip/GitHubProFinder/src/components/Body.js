import ProfileCard from "./ProfileCard";
import { useState, useEffect,useContext } from "react";
import Shimmer from "./Shimmer";
// import { Link, json } from "react-router-dom";
import useOnlineStatus from "../utils/useOnlineStatus";
import { useEffect } from "react";
import { data } from "../utils/constants";
let jsonData = "";
const Body = () => {
  const [searchText, setSearchText] = useState("");
  const onlineStatus = useOnlineStatus();
  if(onlineStatus === false){
    return <h1>Oh no! It looks like you are Offline</h1>
  }
  return (
  <ProfileCard resData = {data}></ProfileCard>
  )
};
export default Body;