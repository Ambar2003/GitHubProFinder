const Contact = () =>{
    return(
        <div>
            <h1 className="my-4 text-2xl">Contact us:8178341272</h1>
            <h2 className="my-4 text-2xl">Email us at gamesutra26@gmail.com</h2>
        </div>
    )
};
export default Contact;